# from django.shortcuts import render
# import numpy as np
# import pandas as pd
# from statsmodels.tsa.arima.model import ARIMA
# import matplotlib.pyplot as plt
# from django.utils.timezone import now
# from expenses.models import Expense
# from django.http import HttpResponse
# from django.contrib import messages

# # Fetch the data from the Expense model and create the forecast
# def forecast(request):
#     # Fetch the latest 30 expenses for the current user
#     expenses = Expense.objects.filter(owner=request.user).order_by('-date')[:30]

#     # Check if there are enough expenses for forecasting
#     if len(expenses) < 10:
#         messages.error(request, "Not enough expenses to make a forecast. Please add more expenses.")
#         return render(request, 'expense_forecast/index.html')

#     # Create a DataFrame from the expenses
#     data = pd.DataFrame({'Date': [expense.date for expense in expenses], 'Expenses': [expense.amount for expense in expenses]})
#     data.set_index('Date', inplace=True)

#     # Fit ARIMA model
#     model = ARIMA(data['Expenses'], order=(5, 1, 0))
#     model_fit = model.fit()

#     # Forecast next 30 days of expenses starting from the next day
#     forecast_steps = 30
#     current_date = now().date()
#     next_day = current_date + pd.DateOffset(days=1)
#     forecast_index = pd.date_range(start=next_day, periods=forecast_steps, freq='D')

#     # Predict the future expenses
#     forecast = model_fit.forecast(steps=forecast_steps)

#     # Create a DataFrame for the forecasted expenses
#     forecast_data = pd.DataFrame({'Date': forecast_index, 'Forecasted_Expenses': forecast})
    
#     # Convert the forecast data to a list of dictionaries
#     forecast_data_list = forecast_data.reset_index().to_dict(orient='records')

#     # Create a plot but save it without displaying it
#     plt.figure(figsize=(10, 6))
#     plt.plot(data, label='Previous Expenses')
#     plt.plot(forecast_index, forecast, label='Forecasted Expenses', color='red')
#     plt.xlabel('Date')
#     plt.ylabel('Expenses')
#     plt.title('Expense Forecast for Next 30 Days')
#     plt.legend()

#     # Save the plot to a file without displaying it
#     plot_file = 'static/img/forecast_plot.png'
#     plt.savefig(plot_file)
#     plt.close()

#     # Pass the data to the template
#     context = {
#         'forecast_data': forecast_data_list,
#         'plot_file': plot_file,
#         'total_forecasted_expenses': np.sum(forecast),
#     }

#     return render(request, 'expense_forecast/index.html', context)

from django.shortcuts import render
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from django.utils.timezone import now
from expenses.models import Expense
from django.http import HttpResponse
from django.contrib import messages
import matplotlib.pyplot as plt
from django.contrib.auth.decorators import login_required
from sklearn.metrics import mean_absolute_error, mean_squared_error


@login_required(login_url='/authentication/login')
def forecast(request):
    # Fetch the latest 30 expenses for the current user
    expenses = Expense.objects.filter(owner=request.user).order_by('-date')[:30]

    if len(expenses) < 5:
        messages.error(request, "Not enough expenses to make a forecast. Please add more expenses.")
        return render(request, 'expense_forecast/index.html')

    # Create a DataFrame
    data = pd.DataFrame({
        'Date': [expense.date for expense in expenses],
        'Expenses': [expense.amount for expense in expenses],
        'Category': [expense.category for expense in expenses]
    })
    data.set_index('Date', inplace=True)
    data = data.sort_index()  # Ensure chronological order

    # Split into train and test (80-20)
    train_size = int(len(data) * 0.8)
    train, test = data['Expenses'][:train_size], data['Expenses'][train_size:]

    # Fit ARIMA model on train data
    model = ARIMA(train, order=(5, 1, 0))
    model_fit = model.fit()

    # Predict on test set
    predictions = model_fit.forecast(steps=len(test))

    # Evaluation metrics
    mae = mean_absolute_error(test, predictions)
    mse = mean_squared_error(test, predictions)
    rmse = np.sqrt(mse)
    mape = np.mean(np.abs((test - predictions) / test)) * 100  # Accuracy as percentage

    # Forecast future 30 days
    forecast_steps = 30
    current_date = now().date()
    next_day = current_date + pd.DateOffset(days=1)
    forecast_index = pd.date_range(start=next_day, periods=forecast_steps, freq='D')
    future_forecast = model_fit.forecast(steps=forecast_steps)

    forecast_data = pd.DataFrame({
        'Date': forecast_index,
        'Forecasted_Expenses': future_forecast
    })

    forecast_data_list = forecast_data.reset_index().to_dict(orient='records')
    total_forecasted_expenses = np.sum(future_forecast)

    # Category wise current data summary
    category_forecasts = data.groupby('Category')['Expenses'].sum().to_dict()

    # Plotting the chart
    plt.figure(figsize=(10, 6))
    plt.plot(data.index, data['Expenses'], label='Historical Expenses')
    plt.plot(forecast_index, future_forecast, label='Forecasted Expenses', color='red')
    plt.xlabel('Date')
    plt.ylabel('Expenses')
    plt.title('Expense Forecast for Next 30 Days')
    plt.legend()
    plot_file = 'static/img/forecast_plot.png'
    plt.savefig(plot_file)
    plt.close()

    context = {
        'forecast_data': forecast_data_list,
        'total_forecasted_expenses': round(total_forecasted_expenses, 2),
        'category_forecasts': category_forecasts,
        'mae': round(mae, 2),
        'mse': round(mse, 2),
        'rmse': round(rmse, 2),
        'mape': round(mape, 2),  # This is the accuracy percentage
        'accuracy_percent': round(100 - mape, 2)  # Rough estimate of forecast accuracy
    }

    return render(request, 'expense_forecast/index.html', context)
