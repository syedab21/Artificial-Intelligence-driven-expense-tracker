console.log("HEmant");
document
  .getElementById("generate-report")
  .addEventListener("click", function () {
    document.getElementById("export-options").classList.remove("hidden");
  });
